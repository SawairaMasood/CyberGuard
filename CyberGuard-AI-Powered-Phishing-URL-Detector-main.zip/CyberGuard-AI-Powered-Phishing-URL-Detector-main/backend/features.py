"""
Feature Extraction Module for Phishing URL Detection

This module extracts lexical features from URLs to help identify potential phishing attempts.
These features are based on common patterns observed in malicious URLs.
"""

import re
from urllib.parse import urlparse


def extract_features(url):
    """
    Extract numerical features from a URL for phishing detection.
    
    Args:
        url (str): The URL to analyze
        
    Returns:
        list: A list of 5 numerical features:
            [url_length, dot_count, has_at_symbol, has_ip_address, suspicious_keyword_count]
    
    Features explained:
    1. URL Length: Phishing URLs are often longer to hide the real domain
    2. Dot Count: Excessive dots indicate multiple subdomains (obfuscation technique)
    3. @ Symbol: Used to trick users about the actual destination domain
    4. IP Address: Legitimate sites rarely use raw IP addresses instead of domain names
    5. Suspicious Keywords: Common words used in phishing attempts (login, verify, etc.)
    """
    
    features = []
    
    # Feature 1: URL Length
    # Phishing URLs tend to be longer as attackers try to make them look legitimate
    # by adding extra subdomains or parameters
    url_length = len(url)
    features.append(url_length)
    
    # Feature 2: Count of dots (.)
    # Multiple dots indicate many subdomains, which is a common phishing technique
    # Example: secure.login.verify.paypal.phishing-site.com
    dot_count = url.count('.')
    features.append(dot_count)
    
    # Feature 3: Presence of "@" symbol
    # The @ symbol in URLs can be used to obfuscate the real domain
    # Example: http://legitimate-site.com@malicious-site.com redirects to malicious-site.com
    has_at_symbol = 1 if '@' in url else 0
    features.append(has_at_symbol)
    
    # Feature 4: Presence of IP address
    # Legitimate websites use domain names, not raw IP addresses
    # This regex checks for IPv4 addresses in the URL
    ip_pattern = r'(\d{1,3}\.){3}\d{1,3}'
    has_ip_address = 1 if re.search(ip_pattern, url) else 0
    features.append(has_ip_address)
    
    # Feature 5: Suspicious keywords
    # Common words used in phishing attempts to create urgency or mimic legitimate services
    suspicious_keywords = ['login', 'verify', 'update', 'secure', 'account', 
                          'banking', 'confirm', 'suspend', 'restore', 'click']
    
    # Convert URL to lowercase for case-insensitive matching
    url_lower = url.lower()
    
    # Count how many suspicious keywords appear in the URL
    suspicious_keyword_count = sum(1 for keyword in suspicious_keywords if keyword in url_lower)
    features.append(suspicious_keyword_count)
    
    return features


# Example usage and testing (can be removed in production)
if __name__ == "__main__":
    # Test with a legitimate URL
    safe_url = "https://www.google.com"
    print(f"Safe URL: {safe_url}")
    print(f"Features: {extract_features(safe_url)}")
    print()
    
    # Test with a suspicious URL
    phishing_url = "http://secure-login-verify-paypal-account.com/update"
    print(f"Phishing URL: {phishing_url}")
    print(f"Features: {extract_features(phishing_url)}")
