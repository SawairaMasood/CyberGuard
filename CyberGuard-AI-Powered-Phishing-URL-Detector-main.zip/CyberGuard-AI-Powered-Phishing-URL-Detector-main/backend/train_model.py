"""
Model Training Script for Phishing URL Detection

This script trains a Random Forest Classifier on URL features to detect phishing attempts.
For demonstration, it uses a small dummy dataset. In production, replace with a real dataset.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import joblib
from features import extract_features


def create_dummy_dataset():
    """
    Create a dummy dataset for demonstration purposes.
    
    Returns:
        pd.DataFrame: DataFrame with 'url' and 'label' columns
        
    Note:
        In production, replace this with a real dataset from sources like:
        - Kaggle: "Phishing Website Dataset" or "Malicious URLs Dataset"
        - PhishTank: https://www.phishtank.com/
        - OpenPhish: https://openphish.com/
        
        Expected CSV format:
        url,label
        http://example.com,0
        http://phishing-site.com,1
        
        Where label: 0 = Safe, 1 = Phishing
    """
    
    # Safe/Legitimate URLs - well-known, trusted websites
    safe_urls = [
        "https://www.google.com",
        "https://github.com",
        "https://www.amazon.com",
        "https://stackoverflow.com",
        "https://www.wikipedia.org"
    ]
    
    # Phishing URLs - suspicious patterns that indicate phishing attempts
    phishing_urls = [
        "http://secure-login-paypal-verify.com/update",
        "http://192.168.1.1/banking/account",
        "http://verify-account-amazon.com/login/confirm",
        "http://secure.update.microsoft-account.xyz/restore",
        "http://click-here@malicious-site.com/banking"
    ]
    
    # Combine URLs and create labels (0 = Safe, 1 = Phishing)
    urls = safe_urls + phishing_urls
    labels = [0] * len(safe_urls) + [1] * len(phishing_urls)
    
    # Create DataFrame
    df = pd.DataFrame({
        'url': urls,
        'label': labels
    })
    
    return df


def load_production_dataset(csv_path):
    """
    Load a real dataset from CSV file.
    
    Args:
        csv_path (str): Path to the CSV file
        
    Returns:
        pd.DataFrame: DataFrame with 'url' and 'label' columns
        
    The CSV should have columns: URL, Label
    where Label can be 'bad' (phishing) or 'good' (safe)
    This function will convert them to numeric: 1 for phishing, 0 for safe
    """
    df = pd.read_csv(csv_path)
    
    # Rename columns to lowercase for consistency
    df.columns = df.columns.str.lower()
    
    # Convert string labels to numeric
    # 'bad' = 1 (phishing), anything else = 0 (safe)
    df['label'] = df['label'].apply(lambda x: 1 if str(x).lower() == 'bad' else 0)
    
    return df


def train_model():
    """
    Train a Random Forest Classifier for phishing detection.
    
    Steps:
    1. Load/create dataset
    2. Extract features from URLs
    3. Split data into training and testing sets
    4. Train Random Forest model
    5. Evaluate model performance
    6. Save trained model to disk
    """
    
    print("=" * 60)
    print("PHISHING URL DETECTOR - MODEL TRAINING")
    print("=" * 60)
    
    # Step 1: Load dataset
    print("\n[1/6] Loading dataset...")
    
    # Using the real CSV dataset
    df = load_production_dataset('phishing_site_urls.csv')
    
    # NOTE: If you want to use the dummy dataset for testing, uncomment the line below
    # df = create_dummy_dataset()
    
    print(f"   ✓ Loaded {len(df)} URLs ({sum(df['label']==0)} safe, {sum(df['label']==1)} phishing)")
    
    # Step 2: Extract features
    print("\n[2/6] Extracting features from URLs...")
    X = []  # Features
    y = []  # Labels
    
    for idx, row in df.iterrows():
        url = row['url']
        label = row['label']
        
        # Extract features using our feature extraction module
        features = extract_features(url)
        X.append(features)
        y.append(label)
    
    X = np.array(X)
    y = np.array(y)
    print(f"   ✓ Extracted {X.shape[1]} features from each URL")
    
    # Step 3: Split data into training and testing sets
    print("\n[3/6] Splitting data (80% train, 20% test)...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"   ✓ Training set: {len(X_train)} samples")
    print(f"   ✓ Testing set: {len(X_test)} samples")
    
    # Step 4: Train Random Forest Classifier
    print("\n[4/6] Training Random Forest Classifier...")
    # Random Forest is chosen because:
    # - Handles non-linear relationships well
    # - Resistant to overfitting
    # - Provides feature importance
    # - Works well with small datasets
    model = RandomForestClassifier(
        n_estimators=100,      # Number of trees in the forest
        max_depth=10,          # Maximum depth of each tree
        random_state=42,       # For reproducibility
        n_jobs=-1              # Use all CPU cores
    )
    model.fit(X_train, y_train)
    print("   ✓ Model training complete")
    
    # Step 5: Evaluate model
    print("\n[5/6] Evaluating model performance...")
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"   ✓ Accuracy: {accuracy * 100:.2f}%")
    
    # Display detailed classification report
    print("\n   Classification Report:")
    print("   " + "-" * 50)
    target_names = ['Safe', 'Phishing']
    report = classification_report(y_test, y_pred, target_names=target_names, zero_division=0)
    for line in report.split('\n'):
        print(f"   {line}")
    
    # Display feature importance
    print("\n   Feature Importance:")
    print("   " + "-" * 50)
    feature_names = ['URL Length', 'Dot Count', 'Has @ Symbol', 
                     'Has IP Address', 'Suspicious Keywords']
    importances = model.feature_importances_
    for name, importance in zip(feature_names, importances):
        print(f"   {name:.<30} {importance:.4f}")
    
    # Step 6: Save model
    print("\n[6/6] Saving model to disk...")
    model_filename = 'model.pkl'
    joblib.dump(model, model_filename)
    print(f"   ✓ Model saved as '{model_filename}'")
    
    print("\n" + "=" * 60)
    print("TRAINING COMPLETE!")
    print("=" * 60)
    print(f"\nThe model is ready to use. Load it in your Flask app with:")
    print(f"   model = joblib.load('{model_filename}')")
    
    return model


if __name__ == "__main__":
    # Train the model
    trained_model = train_model()
    
    # Test the model with a few examples
    print("\n" + "=" * 60)
    print("TESTING MODEL WITH SAMPLE URLs")
    print("=" * 60)
    
    test_urls = [
        "https://www.google.com",
        "http://secure-login-verify-paypal.com/account"
    ]
    
    for url in test_urls:
        features = extract_features(url)
        prediction = trained_model.predict([features])[0]
        probability = trained_model.predict_proba([features])[0]
        
        result = "Phishing" if prediction == 1 else "Safe"
        confidence = probability[prediction] * 100
        
        print(f"\nURL: {url}")
        print(f"Prediction: {result} (Confidence: {confidence:.2f}%)")
