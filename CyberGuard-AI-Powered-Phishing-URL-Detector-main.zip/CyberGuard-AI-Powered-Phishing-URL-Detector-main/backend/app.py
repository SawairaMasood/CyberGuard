"""
Flask API for Phishing URL Detection

This Flask application serves the trained ML model via a REST API.
It receives URLs from the frontend, extracts features, and returns predictions.
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import os
from features import extract_features

# Initialize Flask app
app = Flask(__name__)

# Enable CORS to allow requests from the React frontend
# In production, you should restrict this to your frontend domain:
# CORS(app, resources={r"/predict": {"origins": "https://your-frontend-domain.com"}})
CORS(app)

# Load the trained model
MODEL_PATH = 'model.pkl'

try:
    model = joblib.load(MODEL_PATH)
    print(f"✓ Model loaded successfully from '{MODEL_PATH}'")
except FileNotFoundError:
    print(f"✗ Error: Model file '{MODEL_PATH}' not found!")
    print("  Please run 'python train_model.py' first to train and save the model.")
    model = None


@app.route('/', methods=['GET'])
def home():
    """
    Home endpoint - provides API information
    """
    return jsonify({
        'message': 'CyberGuard Phishing Detection API',
        'version': '1.0',
        'endpoints': {
            '/predict': 'POST - Predict if a URL is phishing or safe'
        },
        'status': 'Model loaded' if model else 'Model not loaded'
    })


@app.route('/predict', methods=['POST'])
def predict():
    """
    Prediction endpoint - analyzes a URL and returns phishing detection results
    
    Request body (JSON):
        {
            "url": "http://example.com"
        }
    
    Response (JSON):
        {
            "url": "http://example.com",
            "prediction": "Safe" or "Phishing",
            "confidence": 95.5,
            "features": [45, 2, 0, 0, 1]
        }
    """
    
    # Check if model is loaded
    if model is None:
        return jsonify({
            'error': 'Model not loaded. Please train the model first.'
        }), 500
    
    try:
        # Get JSON data from request
        data = request.get_json()
        
        # Validate input
        if not data:
            return jsonify({
                'error': 'No data provided. Please send JSON with a "url" field.'
            }), 400
        
        if 'url' not in data:
            return jsonify({
                'error': 'Missing "url" field in request body.'
            }), 400
        
        url = data['url']
        
        # Validate URL is not empty
        if not url or url.strip() == '':
            return jsonify({
                'error': 'URL cannot be empty.'
            }), 400
        
        # Extract features from the URL
        features = extract_features(url)
        
        # Make prediction
        # prediction: 0 = Safe, 1 = Phishing
        prediction = model.predict([features])[0]
        
        # Get probability scores for both classes
        # probabilities[0] = probability of Safe
        # probabilities[1] = probability of Phishing
        probabilities = model.predict_proba([features])[0]
        
        # Determine result and confidence
        if prediction == 1:
            result = "Phishing"
            confidence = probabilities[1] * 100  # Confidence in phishing prediction
        else:
            result = "Safe"
            confidence = probabilities[0] * 100  # Confidence in safe prediction
        
        # Prepare response
        response = {
            'url': url,
            'prediction': result,
            'confidence': round(confidence, 2),
            'features': {
                'url_length': features[0],
                'dot_count': features[1],
                'has_at_symbol': bool(features[2]),
                'has_ip_address': bool(features[3]),
                'suspicious_keywords': features[4]
            }
        }
        
        # Log the prediction
        print(f"Prediction: {url} -> {result} ({confidence:.2f}% confidence)")
        
        return jsonify(response), 200
    
    except Exception as e:
        # Handle any unexpected errors
        print(f"Error during prediction: {str(e)}")
        return jsonify({
            'error': f'An error occurred during prediction: {str(e)}'
        }), 500


@app.route('/health', methods=['GET'])
def health():
    """
    Health check endpoint - useful for monitoring
    """
    return jsonify({
        'status': 'healthy',
        'model_loaded': model is not None
    }), 200


# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        'error': 'Endpoint not found. Available endpoints: /, /predict, /health'
    }), 404


@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'error': 'Internal server error'
    }), 500


if __name__ == '__main__':
    print("=" * 60)
    print("CYBERGUARD PHISHING DETECTION API")
    print("=" * 60)
    print(f"Model status: {'✓ Loaded' if model else '✗ Not loaded'}")
    print("\nStarting Flask server...")
    print("API will be available at: http://localhost:5000")
    print("\nEndpoints:")
    print("  GET  /          - API information")
    print("  POST /predict   - Phishing detection")
    print("  GET  /health    - Health check")
    print("\nPress CTRL+C to stop the server")
    print("=" * 60)
    
    # Run the Flask app
    # debug=True enables auto-reload during development
    # In production, set debug=False and use a production server like Gunicorn
    app.run(debug=True, host='0.0.0.0', port=5000)
