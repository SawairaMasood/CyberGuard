import React, { useState } from 'react';
import axios from 'axios';

/**
 * CyberGuard - AI-Powered Phishing URL Detector
 * 
 * This component provides a user interface for detecting phishing URLs using ML.
 * Users can input a URL, and the system will analyze it and return a prediction
 * with a confidence score.
 */
function App() {
    // State management
    const [url, setUrl] = useState('');                    // User input URL
    const [loading, setLoading] = useState(false);         // Loading state during API call
    const [result, setResult] = useState(null);            // Prediction result from API
    const [error, setError] = useState('');                // Error message

    // API endpoint - update this if your backend runs on a different port
    const API_URL = 'http://localhost:5000/predict';

    /**
     * Handle URL scanning
     * Makes a POST request to the Flask backend with the URL
     */
    const handleScan = async () => {
        // Validation: Check if URL is empty
        if (!url.trim()) {
            setError('Please enter a URL to scan');
            setResult(null);
            return;
        }

        // Reset states
        setError('');
        setResult(null);
        setLoading(true);

        try {
            // Make API request to backend
            const response = await axios.post(API_URL, {
                url: url.trim()
            });

            // Set the result from the API response
            setResult(response.data);

        } catch (err) {
            // Handle errors
            if (err.response) {
                // Server responded with an error
                setError(err.response.data.error || 'An error occurred during analysis');
            } else if (err.request) {
                // Request was made but no response received
                setError('Cannot connect to the server. Make sure the backend is running on port 5000.');
            } else {
                // Something else happened
                setError('An unexpected error occurred');
            }
            console.error('Error:', err);
        } finally {
            setLoading(false);
        }
    };

    /**
     * Handle Enter key press in input field
     */
    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            handleScan();
        }
    };

    /**
     * Reset the form
     */
    const handleReset = () => {
        setUrl('');
        setResult(null);
        setError('');
    };

    return (
        <div className="min-h-screen cyber-grid flex items-center justify-center p-4">
            <div className="w-full max-w-4xl">

                {/* Header Section */}
                <div className="text-center mb-12">
                    {/* Logo/Icon */}
                    <div className="flex justify-center mb-6">
                        <div className="relative">
                            <div className="absolute inset-0 bg-cyber-blue blur-2xl opacity-50 animate-pulse-slow"></div>
                            <svg
                                className="w-20 h-20 relative z-10"
                                viewBox="0 0 24 24"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
                                    stroke="url(#gradient)"
                                    strokeWidth="2"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                />
                                <path
                                    d="M12 16V12M12 8H12.01"
                                    stroke="url(#gradient)"
                                    strokeWidth="2"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                />
                                <defs>
                                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                        <stop offset="0%" stopColor="#00d4ff" />
                                        <stop offset="100%" stopColor="#b026ff" />
                                    </linearGradient>
                                </defs>
                            </svg>
                        </div>
                    </div>

                    {/* Title */}
                    <h1 className="text-5xl md:text-6xl font-bold mb-4 gradient-text">
                        CyberGuard
                    </h1>
                    <p className="text-xl md:text-2xl text-gray-300 mb-2">
                        AI Phishing Detector
                    </p>
                    <p className="text-sm md:text-base text-gray-400 max-w-2xl mx-auto">
                        Powered by Machine Learning • Protect yourself from malicious URLs
                    </p>
                </div>

                {/* Main Card */}
                <div className="glow-border rounded-2xl p-8 md:p-10 backdrop-blur-sm bg-cyber-darker/50">

                    {/* Input Section */}
                    <div className="mb-8">
                        <label
                            htmlFor="url-input"
                            className="block text-sm font-medium text-gray-300 mb-3"
                        >
                            Enter URL to Scan
                        </label>
                        <div className="flex flex-col md:flex-row gap-4">
                            <input
                                id="url-input"
                                type="text"
                                value={url}
                                onChange={(e) => setUrl(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder="https://example.com"
                                className="flex-1 px-6 py-4 bg-cyber-dark border-2 border-cyber-blue/30 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyber-blue transition-all duration-300"
                                disabled={loading}
                            />
                            <button
                                onClick={handleScan}
                                disabled={loading}
                                className="px-8 py-4 bg-gradient-to-r from-cyber-blue to-cyber-purple text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-cyber-blue/50 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 min-w-[140px]"
                            >
                                {loading ? (
                                    <>
                                        <div className="spinner"></div>
                                        <span>Scanning...</span>
                                    </>
                                ) : (
                                    <>
                                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                        </svg>
                                        <span>Scan Now</span>
                                    </>
                                )}
                            </button>
                        </div>
                    </div>

                    {/* Error Message */}
                    {error && (
                        <div className="mb-6 p-4 bg-red-500/10 border-2 border-red-500/50 rounded-xl slide-in-up">
                            <div className="flex items-center gap-3">
                                <svg className="w-6 h-6 text-red-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                <p className="text-red-400 font-medium">{error}</p>
                            </div>
                        </div>
                    )}

                    {/* Result Section */}
                    {result && (
                        <div className="slide-in-up">
                            {/* Phishing Warning */}
                            {result.prediction === 'Phishing' && (
                                <div className="p-6 bg-gradient-to-br from-red-500/20 to-red-600/20 border-2 border-red-500 rounded-xl mb-6">
                                    <div className="flex items-start gap-4">
                                        <div className="flex-shrink-0">
                                            <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center animate-pulse">
                                                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="text-2xl font-bold text-red-400 mb-2">
                                                ⚠️ Phishing Detected!
                                            </h3>
                                            <p className="text-red-300 mb-3">
                                                This URL appears to be a phishing attempt. Do not enter any personal information.
                                            </p>
                                            <div className="flex items-center gap-2">
                                                <span className="text-sm text-red-400 font-semibold">Confidence:</span>
                                                <div className="flex-1 bg-red-900/30 rounded-full h-3 overflow-hidden">
                                                    <div
                                                        className="h-full bg-gradient-to-r from-red-500 to-red-600 transition-all duration-1000 ease-out"
                                                        style={{ width: `${result.confidence}%` }}
                                                    ></div>
                                                </div>
                                                <span className="text-lg font-bold text-red-400">{result.confidence}%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Safe Confirmation */}
                            {result.prediction === 'Safe' && (
                                <div className="p-6 bg-gradient-to-br from-green-500/20 to-green-600/20 border-2 border-green-500 rounded-xl mb-6">
                                    <div className="flex items-start gap-4">
                                        <div className="flex-shrink-0">
                                            <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                                                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                                </svg>
                                            </div>
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="text-2xl font-bold text-green-400 mb-2">
                                                ✓ URL Appears Safe
                                            </h3>
                                            <p className="text-green-300 mb-3">
                                                This URL does not show common phishing indicators. However, always exercise caution.
                                            </p>
                                            <div className="flex items-center gap-2">
                                                <span className="text-sm text-green-400 font-semibold">Confidence:</span>
                                                <div className="flex-1 bg-green-900/30 rounded-full h-3 overflow-hidden">
                                                    <div
                                                        className="h-full bg-gradient-to-r from-green-500 to-green-600 transition-all duration-1000 ease-out"
                                                        style={{ width: `${result.confidence}%` }}
                                                    ></div>
                                                </div>
                                                <span className="text-lg font-bold text-green-400">{result.confidence}%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Feature Analysis */}
                            <div className="bg-cyber-dark/50 rounded-xl p-6 border border-cyber-blue/20">
                                <h4 className="text-lg font-semibold text-gray-300 mb-4 flex items-center gap-2">
                                    <svg className="w-5 h-5 text-cyber-blue" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                                    </svg>
                                    Feature Analysis
                                </h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div className="flex justify-between items-center p-3 bg-cyber-darker rounded-lg">
                                        <span className="text-gray-400">URL Length</span>
                                        <span className="text-white font-semibold">{result.features.url_length}</span>
                                    </div>
                                    <div className="flex justify-between items-center p-3 bg-cyber-darker rounded-lg">
                                        <span className="text-gray-400">Dot Count</span>
                                        <span className="text-white font-semibold">{result.features.dot_count}</span>
                                    </div>
                                    <div className="flex justify-between items-center p-3 bg-cyber-darker rounded-lg">
                                        <span className="text-gray-400">@ Symbol</span>
                                        <span className={`font-semibold ${result.features.has_at_symbol ? 'text-red-400' : 'text-green-400'}`}>
                                            {result.features.has_at_symbol ? 'Yes ⚠️' : 'No ✓'}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-center p-3 bg-cyber-darker rounded-lg">
                                        <span className="text-gray-400">IP Address</span>
                                        <span className={`font-semibold ${result.features.has_ip_address ? 'text-red-400' : 'text-green-400'}`}>
                                            {result.features.has_ip_address ? 'Yes ⚠️' : 'No ✓'}
                                        </span>
                                    </div>
                                    <div className="flex justify-between items-center p-3 bg-cyber-darker rounded-lg md:col-span-2">
                                        <span className="text-gray-400">Suspicious Keywords</span>
                                        <span className={`font-semibold ${result.features.suspicious_keywords > 0 ? 'text-red-400' : 'text-green-400'}`}>
                                            {result.features.suspicious_keywords} {result.features.suspicious_keywords > 0 ? '⚠️' : '✓'}
                                        </span>
                                    </div>
                                </div>
                            </div>

                            {/* Reset Button */}
                            <button
                                onClick={handleReset}
                                className="mt-6 w-full px-6 py-3 bg-cyber-dark border-2 border-cyber-blue/30 text-cyber-blue font-semibold rounded-xl hover:bg-cyber-blue/10 hover:border-cyber-blue transition-all duration-300"
                            >
                                Scan Another URL
                            </button>
                        </div>
                    )}

                    {/* Info Section */}
                    {!result && !error && !loading && (
                        <div className="text-center py-8">
                            <svg className="w-16 h-16 mx-auto mb-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                            </svg>
                            <p className="text-gray-400 text-sm">
                                Enter a URL above to analyze it for phishing indicators using AI
                            </p>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="text-center mt-8 text-gray-500 text-sm">
                    <p>Powered by Machine Learning • Random Forest Classifier</p>
                    <p className="mt-2">Built with React, Flask, and Scikit-Learn</p>
                </div>
            </div>
        </div>
    );
}

export default App;
