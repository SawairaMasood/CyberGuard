# 🛡️ CyberGuard: AI-Powered Phishing URL Detector

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![Flask](https://img.shields.io/badge/Flask-3.0-green.svg)
![React](https://img.shields.io/badge/React-18.2-61DAFB.svg)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.3-38B2AC.svg)
![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.3-F7931E.svg)

A modern web application that uses Machine Learning to detect phishing URLs based on lexical feature extraction. Built with Python (Flask + Scikit-Learn) for the backend and React with Tailwind CSS for the frontend.

## 🌟 Features

- **AI-Powered Detection**: Uses a Random Forest Classifier trained on URL features
- **Real-time Analysis**: Instant phishing detection with confidence scores
- **Feature Extraction**: Analyzes 5 key lexical features:
  - URL length
  - Dot count (subdomain analysis)
  - @ symbol presence
  - IP address detection
  - Suspicious keyword matching
- **Modern UI**: Dark-themed, cyber-styled interface with smooth animations
- **Visual Feedback**: Color-coded results (Red for Phishing, Green for Safe)
- **Detailed Analysis**: Shows feature breakdown and confidence metrics

## 📸 Screenshots

### Main Interface
The application features a modern dark-themed interface with a cyber aesthetic, complete with gradient backgrounds and smooth animations.

![Main Interface](screenshots/main.png)

### Phishing Detection
When a suspicious URL is detected, the app displays a red warning card with high confidence scores and detailed feature analysis.

![Phishing Detection](screenshots/phishing.png)

### Safe URL Detection
Legitimate URLs are shown with a green success card, providing users with confidence in their browsing safety.

![Safe URL](screenshots/safe.png)

## 🚀 Tech Stack

### Backend
- **Python 3.8+**
- **Flask** - REST API framework
- **Scikit-Learn** - Machine Learning (Random Forest)
- **Pandas & NumPy** - Data processing
- **Joblib** - Model serialization

### Frontend
- **React 18** - UI framework
- **Vite** - Build tool
- **Tailwind CSS 3** - Styling
- **Axios** - HTTP client

## 📁 Project Structure

```
URL/
├── backend/
│   ├── features.py          # Feature extraction logic
│   ├── train_model.py       # Model training script
│   ├── app.py               # Flask API server
│   ├── requirements.txt     # Python dependencies
│   └── model.pkl            # Trained model (generated)
├── frontend/
│   ├── src/
│   │   ├── App.jsx          # Main React component
│   │   ├── main.jsx         # React entry point
│   │   └── index.css        # Tailwind CSS + custom styles
│   ├── index.html           # HTML template
│   ├── package.json         # Node dependencies
│   ├── vite.config.js       # Vite configuration
│   ├── tailwind.config.js   # Tailwind configuration
│   └── postcss.config.js    # PostCSS configuration
└── README.md
```

## 🔧 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- Node.js 16 or higher
- npm or yarn

### Backend Setup

1. **Navigate to the backend directory**:
   ```bash
   cd backend
   ```

2. **Create a virtual environment** (recommended):
   ```bash
   python -m venv venv
   
   # On Windows
   venv\Scripts\activate
   
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install Python dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Train the model**:
   ```bash
   python train_model.py
   ```
   This will create a `model.pkl` file with the trained Random Forest classifier.

5. **Start the Flask server**:
   ```bash
   python app.py
   ```
   The API will be available at `http://localhost:5000`

### Frontend Setup

1. **Navigate to the frontend directory**:
   ```bash
   cd frontend
   ```

2. **Install Node dependencies**:
   ```bash
   npm install
   ```

3. **Start the development server**:
   ```bash
   npm run dev
   ```
   The app will open at `http://localhost:3000`

## 🎯 Usage

1. **Start both servers** (backend on port 5000, frontend on port 3000)
2. **Open your browser** to `http://localhost:3000`
3. **Enter a URL** in the input field
4. **Click "Scan Now"** or press Enter
5. **View the results**:
   - **Red card** = Phishing detected
   - **Green card** = URL appears safe
   - See confidence score and feature analysis

### Example URLs to Test

**Safe URLs**:
- `https://www.google.com`
- `https://github.com`
- `https://www.amazon.com`

**Phishing URLs** (for testing):
- `http://secure-login-paypal-verify.com/update`
- `http://verify-account-amazon.com/login/confirm`
- `http://192.168.1.1/banking/account`

## 🧠 How It Works

### Feature Extraction
The system analyzes URLs based on these features:

1. **URL Length**: Phishing URLs are often longer to hide the real domain
2. **Dot Count**: Excessive dots indicate multiple subdomains (obfuscation)
3. **@ Symbol**: Used to trick users about the actual destination
4. **IP Address**: Legitimate sites rarely use raw IP addresses
5. **Suspicious Keywords**: Common phishing terms (login, verify, update, etc.)

### Machine Learning Model
- **Algorithm**: Random Forest Classifier
- **Training**: Uses lexical features extracted from URLs
- **Output**: Binary classification (Safe/Phishing) with confidence score

### API Endpoint
```
POST /predict
Content-Type: application/json

{
  "url": "http://example.com"
}

Response:
{
  "url": "http://example.com",
  "prediction": "Safe",
  "confidence": 95.5,
  "features": {
    "url_length": 21,
    "dot_count": 2,
    "has_at_symbol": false,
    "has_ip_address": false,
    "suspicious_keywords": 0
  }
}
```

## 📊 Using a Real Dataset

The current implementation uses a **dummy dataset** for demonstration. For production use:

1. **Download a phishing dataset** from:
   - [Kaggle - Phishing Website Dataset](https://www.kaggle.com/)
   - [PhishTank](https://www.phishtank.com/)
   - [OpenPhish](https://openphish.com/)

2. **Prepare your CSV** with columns: `url`, `label` (0=Safe, 1=Phishing)

3. **Update `train_model.py`**:
   ```python
   # Comment out the dummy dataset line
   # df = create_dummy_dataset()
   
   # Uncomment and use the production dataset
   df = load_production_dataset('your_dataset.csv')
   ```

4. **Retrain the model**:
   ```bash
   python train_model.py
   ```

**⚠️ Disclaimer**: This tool is for educational purposes. Always exercise caution when clicking on unknown URLs, regardless of the prediction.

